package com.example.Allen.Allen.Service;

import com.example.Allen.Allen.Exception.CalanderExceptions;
import com.example.Allen.Allen.Modal.User;
import com.example.Allen.Allen.Repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Objects;
@Service
public class InviteUserService {

    @Autowired
    private UserRepository userRepository;
    HashMap<String, List<String>>allInvitations = new HashMap<>();
    HashMap<String,String>UserStatus = new HashMap<>();

    HashMap<String,String>scheduledEvents = new HashMap<>();
    public String InviteUsers(String eventId,List<String>user)throws CalanderExceptions {
        if(allInvitations.get(eventId)!=null){
            throw new CalanderExceptions("EVENT ALREADY EXISTS");
        }
        allInvitations.put(eventId,user);
        return "USER HAS BEEN INVITED";
    }
    public String UpdateUserStatus(String userId,Integer day,String evenId,String status) throws CalanderExceptions {
        User user = userRepository.getUser(userId);
        if(Objects.isNull(user)){
            throw new CalanderExceptions("NO USER EXISTS");
        }
        if(Objects.equals(status, "ACCEPTED")){
            scheduledEvents.put(day+userId,evenId);
        }
        UserStatus.put(userId,status);
        return "USER STATUS HAS BEEN UPDATED";
    }
    public String getScheduledEvents(String userId,Integer day) throws CalanderExceptions{
        User user= userRepository.getUser(userId);
        if(user==null){
            throw new CalanderExceptions("USER DOES NOT EXISTS");
        }
        return "Schedueld event for " + scheduledEvents.getOrDefault(day+userId,"NONE");
    }


}
