package com.example.Allen.Allen.Modal;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Event {
    private String eventId;
    private String organizer;
    private String eventName;
    private Integer startTime;
    private Integer endTime;
    private Integer day;
}
