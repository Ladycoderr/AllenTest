package com.example.Allen.Allen.Repository;

import com.example.Allen.Allen.Modal.User;
import org.springframework.stereotype.Repository;

import java.util.HashMap;

@Repository
public class UserRepository {
    HashMap<String,User>users = new HashMap<>();
    public void addUser(User user){
        users.put(user.getUser_id(),user);
        System.out.println(users);
    }
    public void UpdateUser(String Userid,User user){
        User prevUser = users.get(Userid);
        if(user.getUser_email()!=null){
            prevUser.setUser_email(user.getUser_email());
        }
        System.out.println(users);
    }
    public User getUser(String userId) {
        return users.get(userId);
    }

}
