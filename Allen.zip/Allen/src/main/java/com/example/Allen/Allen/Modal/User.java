package com.example.Allen.Allen.Modal;

import lombok.*;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class User {
    private String user_id;
    private String user_email;
}

