package com.example.Allen.Allen.Exception;

public class CalanderExceptions extends Exception{
    public CalanderExceptions(String msg){
        super(msg);
    }
}
