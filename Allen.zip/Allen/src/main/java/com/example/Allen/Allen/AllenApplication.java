package com.example.Allen.Allen;

import com.example.Allen.Allen.Controller.TestController;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;

@SpringBootApplication
public class AllenApplication {

	public static void main(String[] args) {

		ApplicationContext app= SpringApplication.run(AllenApplication.class, args);
		TestController ts = app.getBean(TestController.class);
		ts.allTestCases();

	}

}
