package com.example.Allen.Allen.Controller;

import com.example.Allen.Allen.Exception.CalanderExceptions;
import com.example.Allen.Allen.Service.EventService;
import com.example.Allen.Allen.Service.InviteUserService;
import com.example.Allen.Allen.Service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import java.util.ArrayList;
import java.util.List;

@Controller
public class TestController {
    @Autowired
    private UserService userService;
    @Autowired
    private InviteUserService inviteUserService;
    @Autowired
    private EventService eventService;
    public void allTestCases(){
        System.out.println(userService.addUser("USER1","hello@123"));
        System.out.println(userService.addUser("USER2","hello@gmail"));
        System.out.println(userService.UpdateUser("USER1","world@123"));
        try {
            System.out.println(eventService.addEvent("E1","ADMIN","MEETING",12,13,4));

        }
        catch (CalanderExceptions e){
            System.out.println(e.getMessage());
        }

        List<String>UserIdsTobeInvited = new ArrayList<>();
        UserIdsTobeInvited.add("USER1");
        UserIdsTobeInvited.add("USER2");
        try {
            System.out.println(inviteUserService.InviteUsers("E1",UserIdsTobeInvited));
        }
        catch (CalanderExceptions e){
            System.out.println(e.getMessage());
        }
        try {
            System.out.println(inviteUserService.UpdateUserStatus("USER1",4,"E1","REJECTED"));
            System.out.println(inviteUserService.UpdateUserStatus("USER2",4,"E1","ACCEPTED"));
        }
        catch (CalanderExceptions e){
            System.out.println(e.getMessage());
        }

        try {
            System.out.println(inviteUserService.getScheduledEvents("USER1",4));
            System.out.println(inviteUserService.getScheduledEvents("USER2",4));
        } catch (CalanderExceptions e) {
            System.out.println(e.getMessage());
        }

    }
}
