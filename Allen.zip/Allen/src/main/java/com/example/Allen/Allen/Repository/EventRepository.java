package com.example.Allen.Allen.Repository;

import com.example.Allen.Allen.Modal.Event;
import org.springframework.stereotype.Repository;

import java.util.HashMap;
import java.util.Objects;
@Repository
public class EventRepository {
    HashMap<String,Event>allEvents = new HashMap<>();
    public void addEvent(Event event) {
        allEvents.put(event.getEventId(),event);
        System.out.println(allEvents);
    }
    public void upDateEvent(String eventId,Event event) {
       Event PrevEvent = allEvents.get(eventId);
       if(event.getEventName()!=null){
           PrevEvent.setEventName(event.getEventName());
       }
        if(event.getOrganizer()!=null){
            PrevEvent.setOrganizer(event.getOrganizer());
        }
        if(event.getStartTime()!=null){
            PrevEvent.setStartTime(event.getStartTime());
        }
        if(event.getEventName()!=null){
            PrevEvent.setEndTime(event.getEndTime());
        }
        System.out.println(allEvents);
    }

    public Event getEvent(String eventId) {
        return allEvents.get(eventId);
    }
}
