package com.example.Allen.Allen.Service;

import com.example.Allen.Allen.Modal.User;
import com.example.Allen.Allen.Repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class UserService {
    @Autowired
    UserRepository userRepository;
    public String addUser(String UserId, String userEmail){
        User user = new User(UserId,userEmail);
        userRepository.addUser(user);
        return "USER HAS BEEN ADDED";
    }
    public String UpdateUser(String UserId, String userEmail){
        User user = new User(UserId,userEmail);
        userRepository.UpdateUser(UserId,user);
        return "USER HAS BEEN UPDATE";
    }

}
