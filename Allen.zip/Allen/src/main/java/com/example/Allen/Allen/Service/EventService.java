package com.example.Allen.Allen.Service;

import com.example.Allen.Allen.Exception.CalanderExceptions;
import com.example.Allen.Allen.Modal.Event;
import com.example.Allen.Allen.Repository.EventRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Objects;

@Service
public class EventService {
    @Autowired
    private EventRepository eventRepository;
    public String addEvent(String eventId,String organizer, String eventName,Integer startTime,Integer endTime,Integer day)throws CalanderExceptions{
        Event event = new Event(eventId,organizer,eventName,startTime,endTime,day);
        if(startTime>endTime){
            throw new CalanderExceptions("STARTIME SHOULD BE LESS THAN ENDTIME");
        }
        eventRepository.addEvent(event);

        return "EVENT HAS BEEN CREATED";
    }
    public String updateEvent(String eventId,Event event) throws CalanderExceptions {
        Event getEvent = eventRepository.getEvent(eventId);
        if(Objects.isNull(event)){
            throw new CalanderExceptions("NO EVENT EXISTS");
        }
        eventRepository.upDateEvent(eventId,event);
        return "EVENT HAS BEEN Updated";
    }
}
