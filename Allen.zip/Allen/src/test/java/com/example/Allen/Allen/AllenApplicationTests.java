package com.example.Allen.Allen;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AllenApplicationTests {

	@Test
	void contextLoads() {
	}

}
